import { Decal, useTexture } from '@react-three/drei';
import * as THREE from 'three';
import { Common3DProps } from '../types';

export default function Mug({
                                position = [0, 0, 0],
                                rotation = [0, 0, 0],
                            }: Common3DProps) {
    const logo = useTexture('/textures/rootme-logo.png');

    logo.wrapS = THREE.ClampToEdgeWrapping;
    logo.wrapT = THREE.ClampToEdgeWrapping;
    logo.anisotropy = 8;

    return (
        <group position={position} rotation={rotation} scale={1.12}>
            {/* Corps extérieur blanc */}
            <mesh castShadow receiveShadow position={[0, 0.07, 0]}>
                <cylinderGeometry args={[0.08, 0.075, 0.14, 64]} />
                <meshStandardMaterial
                    color="#ffffff"
                    roughness={0.28}
                    metalness={0.03}
                />

                {/* Logo */}
                <Decal
                    position={[0, -0.005, 0.081]}
                    rotation={[0, 0, 0]}
                    scale={[0.12, 0.12, 0.12]}
                >
                    <meshStandardMaterial
                        map={logo}
                        transparent
                        alphaTest={0.08}
                        polygonOffset
                        polygonOffsetFactor={-2}
                        toneMapped={false}
                        color="#111111"
                    />
                </Decal>
            </mesh>

            {/* Fond extérieur */}
            <mesh castShadow receiveShadow position={[0, 0.005, 0]}>
                <cylinderGeometry args={[0.055, 0.06, 0.01, 64]} />
                <meshStandardMaterial
                    color="#f3f3f3"
                    roughness={0.35}
                    metalness={0.02}
                />
            </mesh>

            {/* Paroi intérieure noire */}
            <mesh castShadow receiveShadow position={[0, 0.075, 0]}>
                <cylinderGeometry args={[0.068, 0.064, 0.12, 64, 1, true]} />
                <meshStandardMaterial
                    color="#111111"
                    roughness={0.22}
                    metalness={0.1}
                    side={THREE.DoubleSide}
                />
            </mesh>

            {/* Fond intérieur noir */}
            <mesh castShadow receiveShadow position={[0, 0.016, 0]}>
                <cylinderGeometry args={[0.064, 0.064, 0.008, 64]} />
                <meshStandardMaterial
                    color="#111111"
                    roughness={0.22}
                    metalness={0.1}
                />
            </mesh>

            {/* Rebord noir */}
            <mesh
                castShadow
                receiveShadow
                position={[0, 0.14, 0]}
                rotation={[Math.PI / 2, 0, 0]}
            >
                <torusGeometry args={[0.074, 0.0075, 24, 96]} />
                <meshStandardMaterial
                    color="#111111"
                    roughness={0.24}
                    metalness={0.1}
                />
            </mesh>

            {/* Anse complète noire */}
            <mesh
                castShadow
                receiveShadow
                position={[0.108, 0.075, 0]}
                rotation={[0, 0, Math.PI / 2]}
            >
                <torusGeometry args={[0.05, 0.012, 24, 96, Math.PI * 2]} />
                <meshStandardMaterial
                    color="#111111"
                    roughness={0.24}
                    metalness={0.1}
                />
            </mesh>
        </group>
    );
}